# EduDesk 🏫
### Education IT & Services Portal — Next.js · MySQL · Prisma · Multi-Tenant SaaS

A production-ready, **multi-tenant** helpdesk and IT ticketing system built for schools, colleges, and universities. Supports **LDAP / Azure AD / Google Workspace SSO**, white-label branding, per-tenant licensing, file attachments, SLA enforcement, a rich knowledge base, and WYSIWYG ticket communication.

---

## ✨ Key Features

| Feature | Details |
|---|---|
| **Multi-tenancy** | Full tenant isolation — each institution has its own data, branding, and config |
| **SSO / Directory Sync** | LDAP, Azure Active Directory, Google Workspace — auth + user provisioning |
| **Role-Based Access** | 6 roles: Super Admin, Tenant Admin, IT Agent, Teacher, Staff, Student |
| **WYSIWYG Tickets** | Rich-text submission and replies (bold, italic, underline, headings, lists) |
| **File Attachments** | Upload at ticket creation or per-reply; configurable quota and allowed file types |
| **Knowledge Base** | Per-tenant KB articles with rich HTML content, role-based visibility |
| **SLA Engine** | Configurable response / resolve targets per priority; breach tracking |
| **White-Label Branding** | Custom logo, colors, font, portal title, CSS — controlled per tenant |
| **Category Trees** | Hierarchical ticket categories with agent permission scoping |
| **Department Routing** | Configurable departments; agents scoped to specific departments & categories |
| **SMTP Per-Tenant** | Each tenant can configure their own outbound mail server |
| **Feature Flags** | Super admin can enable/disable Branding and Integrations per tenant |
| **License Management** | Plans (Starter, Professional, District, University) with user/agent/storage limits |
| **Analytics & Reports** | Ticket volume, resolution time, SLA compliance, per-department breakdowns |
| **Audit Log** | Full action history for compliance tracking |
| **Notifications** | In-app notification queue per user |

---

## 🗂 Project Structure

```
edudesk/
├── prisma/
│   ├── schema.prisma          # Full MySQL schema (20 models)
│   └── seed.ts                # Sample data seeder
├── src/
│   ├── app/
│   │   ├── api/               # 39 API route handlers
│   │   │   ├── auth/          # NextAuth (credentials + SSO)
│   │   │   ├── tickets/       # Ticket CRUD, messages, attachments, eligible agents
│   │   │   ├── kb/            # KB article search (portal)
│   │   │   ├── users/         # User lookup helpers
│   │   │   ├── reports/       # Analytics endpoints
│   │   │   ├── departments/   # Public department list
│   │   │   ├── portal/        # Branding + storage config (portal public read)
│   │   │   ├── tenant/        # Tenant Admin management routes
│   │   │   │   ├── ad-config/      # SSO config (LDAP/Azure/Google)
│   │   │   │   ├── ad-sync/        # LDAP sync trigger
│   │   │   │   ├── azure-sync/     # Azure AD sync trigger
│   │   │   │   ├── google-sync/    # Google Workspace sync trigger
│   │   │   │   ├── agents/[id]/categories/  # Agent permission editor
│   │   │   │   ├── branding/       # White-label branding
│   │   │   │   ├── categories/     # Category tree management
│   │   │   │   ├── departments/    # Department config
│   │   │   │   ├── email-templates/ # Email template editor
│   │   │   │   ├── kb/             # KB article CRUD
│   │   │   │   ├── performance/    # Perf metrics
│   │   │   │   ├── priority-config/ # Priority/SLA config
│   │   │   │   ├── smtp/           # SMTP config
│   │   │   │   └── users/          # User management (list, create, edit)
│   │   │   ├── super-admin/   # Platform-wide admin routes
│   │   │   │   ├── audit/          # Global audit log
│   │   │   │   ├── licenses/[tenantId]/  # License management
│   │   │   │   ├── smtp/           # Global SMTP (fallback)
│   │   │   │   ├── stats/          # Platform statistics
│   │   │   │   ├── tenants/        # Tenant CRUD
│   │   │   │   └── tenants/[id]/features/  # Feature flag toggles
│   │   │   └── institution/   # Legacy institution routes
│   │   ├── dashboard/         # IT Agent / Tenant Admin dashboard
│   │   ├── portal/            # Student / Teacher / Staff portal
│   │   ├── tenant-admin/      # Tenant Admin settings panel
│   │   ├── super-admin/       # Super Admin platform console
│   │   └── login/             # Unified login page
│   ├── lib/
│   │   ├── prisma.ts          # Prisma client singleton
│   │   └── api.ts             # Auth helpers, response utilities
│   ├── types/                 # Shared TypeScript types
│   └── middleware.ts          # Route protection + role-based redirect
├── components/                # Shared React components
├── types/                     # Global type declarations
├── .env.example
├── package.json
└── README.md
```

---

## ⚡ Quick Start

### 1. Prerequisites
- **Node.js** 18+
- **MySQL** 8.0+
- (Optional) LDAP / Azure AD / Google Workspace for SSO

### 2. Clone & Install
```bash
git clone https://github.com/yourorg/edudesk.git
cd edudesk
npm install
```

### 3. Configure Environment
```bash
cp .env.example .env.local
```

Edit `.env.local`:
```env
# ─── Database ────────────────────────────────────────
DATABASE_URL="mysql://root:yourpassword@localhost:3306/edudesk"

# ─── NextAuth ────────────────────────────────────────
# Generate secret: openssl rand -base64 32
NEXTAUTH_URL="http://localhost:3000"
NEXTAUTH_SECRET="your-32-char-secret-here"

# ─── File Storage (optional) ─────────────────────────
# Defaults to ./uploads/ if not set
UPLOAD_DIR="/var/edudesk/uploads"
```

> **SSO credentials** (LDAP URLs, Azure secrets, Google service account) are stored **per-tenant in the database** and configured through the Tenant Admin panel — not in `.env`.

### 4. Create MySQL Database
```sql
CREATE DATABASE edudesk CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
```

### 5. Push Schema & Seed
```bash
# Push schema to database
npm run db:push

# (Optional) Seed with sample data
npx ts-node prisma/seed.ts
```

### 6. Start Development Server
```bash
npm run dev
```

Visit **http://localhost:3000**

---

## 🛠 Development Commands

```bash
npm run dev          # Start dev server (port 3000)
npm run build        # Production build
npm start            # Start production server
npm run lint         # ESLint check
npm run generate     # Regenerate Prisma client
npm run db:push      # Push schema changes to DB (no migration files)
npm run db:studio    # Open Prisma Studio (visual DB browser)
```

---

## 🔐 Roles & Access

EduDesk uses **6 roles** across two scopes:

### Platform Scope
| Role | Scope | Description |
|---|---|---|
| `SUPER_ADMIN` | Global | Manages all tenants, licenses, feature flags, global SMTP, audit logs |

### Tenant Scope
| Role | Description |
|---|---|
| `TENANT_ADMIN` | Manages the tenant — users, agents, branding, SSO, KB, categories, SLA |
| `IT_AGENT` | Works tickets, replies, assigns, updates status; scoped by dept/category |
| `TEACHER` | Submits and tracks own tickets via the portal |
| `STAFF` | Submits and tracks own tickets via the portal |
| `STUDENT` | Submits and tracks own tickets via the portal |

### Permission Matrix

| Feature | Student | Teacher | Staff | IT Agent | Tenant Admin | Super Admin |
|---|:---:|:---:|:---:|:---:|:---:|:---:|
| Submit tickets | ✅ | ✅ | ✅ | ✅ | ✅ | — |
| View own tickets | ✅ | ✅ | ✅ | ✅ | ✅ | — |
| View all tickets | ❌ | ❌ | ❌ | ✅ | ✅ | — |
| Reply to tickets | ✅ | ✅ | ✅ | ✅ | ✅ | — |
| Internal notes | ❌ | ❌ | ❌ | ✅ | ✅ | — |
| Assign / re-assign | ❌ | ❌ | ❌ | ✅ | ✅ | — |
| Change ticket status | ❌ | ❌ | ❌ | ✅ | ✅ | — |
| Upload attachments | ✅ | ✅ | ✅ | ✅ | ✅ | — |
| Browse Knowledge Base | ✅ | ✅ | ✅ | ✅ | ✅ | — |
| Manage KB articles | ❌ | ❌ | ❌ | ❌ | ✅ | — |
| View analytics | ❌ | ❌ | ❌ | ✅ | ✅ | — |
| Manage users | ❌ | ❌ | ❌ | ❌ | ✅ | — |
| Configure SSO / AD | ❌ | ❌ | ❌ | ❌ | ✅ | — |
| Configure branding | ❌ | ❌ | ❌ | ❌ | ✅ | — |
| Configure SLA | ❌ | ❌ | ❌ | ❌ | ✅ | — |
| Manage categories | ❌ | ❌ | ❌ | ❌ | ✅ | — |
| Manage all tenants | ❌ | ❌ | ❌ | ❌ | ❌ | ✅ |
| Manage licenses | ❌ | ❌ | ❌ | ❌ | ❌ | ✅ |
| Toggle feature flags | ❌ | ❌ | ❌ | ❌ | ❌ | ✅ |

---

## 🗄 Database Schema

EduDesk v3 uses **20 Prisma models** on MySQL with full multi-tenant isolation.

### Models Overview

| Model | Table | Description |
|---|---|---|
| `Tenant` | `tenants` | Institution record; holds `brandingEnabled`, `adEnabled` feature flags |
| `TenantBranding` | `tenant_branding` | Logo, colors, fonts, portal title, custom CSS |
| `AdConfig` | `ad_configs` | SSO config for LDAP, Azure AD, Google Workspace |
| `License` | `licenses` | Plan, limits (users, agents, storage, KB), feature entitlements |
| `TenantStorageConfig` | `tenant_storage_configs` | Per-tenant file storage quota and allowed extensions |
| `User` | `users` | All users; supports local password, AD/SSO provisioning |
| `Category` | `categories` | Hierarchical ticket categories (tree via `parentId`) |
| `AgentCategory` | `agent_categories` | Scopes an agent to specific categories |
| `AgentDepartment` | `agent_departments` | Scopes an agent to specific departments |
| `Ticket` | `tickets` | Core ticket with status, priority, dept, category, SLA tracking |
| `TicketMessage` | `ticket_messages` | Thread messages; `isInternal` flag for agent-only notes |
| `TicketAttachment` | `ticket_attachments` | File attachments; `messageId` is null for submission-time files |
| `TicketActivity` | `ticket_activities` | Full audit trail of ticket events |
| `SlaLog` | `sla_logs` | SLA breach tracking per ticket |
| `KbArticle` | `kb_articles` | Rich HTML knowledge base articles with role-based visibility |
| `DepartmentConfig` | `department_configs` | Per-tenant department labels, icons, routing email |
| `SlaConfig` | `sla_configs` | SLA targets (response / resolve hours) per priority level |
| `SmtpConfig` | `smtp_configs` | Per-tenant SMTP credentials |
| `Notification` | `notifications` | In-app notification queue |
| `AuditLog` | `audit_logs` | Global audit log for compliance |

### Entity Relationships
```
Tenant ─┬─< Users
        ├─< Tickets ──< TicketMessages ──< TicketAttachments
        │              └──< TicketActivities
        │              └──1 SlaLog
        ├─1 TenantBranding
        ├─1 AdConfig
        ├─1 License
        ├─1 TenantStorageConfig
        ├─1 SmtpConfig
        ├─< Categories (self-referencing tree)
        ├─< DepartmentConfigs
        ├─< SlaConfigs
        ├─< KbArticles
        ├─< Notifications
        └─< AuditLogs

Users ──< AgentCategories ──> Categories
Users ──< AgentDepartments
```

---

## 🌐 API Endpoints

### Authentication
| Method | Endpoint | Description |
|---|---|---|
| POST | `/api/auth/[...nextauth]` | NextAuth — credentials & SSO sign-in / sign-out |

### Tickets
| Method | Endpoint | Access |
|---|---|---|
| GET | `/api/tickets` | All roles (filtered by ownership/dept/category for agents) |
| POST | `/api/tickets` | All roles — creates ticket + initial attachments |
| GET | `/api/tickets/[id]` | All roles (own, or agent/admin) |
| PATCH | `/api/tickets/[id]` | Agent + Admin — status, assignee, priority |
| GET | `/api/tickets/[id]/messages` | All roles |
| POST | `/api/tickets/[id]/messages` | All roles — WYSIWYG reply with attachments |
| GET | `/api/tickets/[id]/attachments` | All roles |
| GET | `/api/tickets/[id]/attachments/[uid]/download` | File download (signed path) |
| GET | `/api/tickets/[id]/eligible-agents` | Admin + Agent — list agents eligible to be assigned |

### Knowledge Base
| Method | Endpoint | Access |
|---|---|---|
| GET | `/api/kb` | All roles (portal KB search) |

### Portal (Public Tenant Config)
| Method | Endpoint | Access |
|---|---|---|
| GET | `/api/portal/branding` | Public — returns branding for tenant by domain/slug |
| GET | `/api/portal/storage-config` | Public — storage limits for file upload UI |

### Reports
| Method | Endpoint | Access |
|---|---|---|
| GET | `/api/reports` | Agent + Admin |

### Departments
| Method | Endpoint | Access |
|---|---|---|
| GET | `/api/departments` | All roles |

### Users
| Method | Endpoint | Access |
|---|---|---|
| GET | `/api/users` | Agent + Admin |

### Tenant Admin
| Method | Endpoint | Description |
|---|---|---|
| GET/PATCH | `/api/tenant/branding` | White-label branding settings |
| GET/PATCH | `/api/tenant/ad-config` | SSO config (LDAP / Azure / Google) |
| POST | `/api/tenant/ad-sync` | Trigger LDAP sync |
| POST | `/api/tenant/azure-sync` | Trigger Azure AD sync |
| POST | `/api/tenant/google-sync` | Trigger Google Workspace sync |
| GET/POST/PATCH/DELETE | `/api/tenant/categories` | Category tree CRUD |
| GET/POST/PATCH/DELETE | `/api/tenant/departments` | Department config CRUD |
| GET/PATCH | `/api/tenant/email-templates` | Email notification templates |
| GET/POST/PATCH/DELETE | `/api/tenant/kb` | KB article CRUD |
| GET | `/api/tenant/performance` | Performance dashboard metrics |
| GET/PATCH | `/api/tenant/priority-config` | SLA targets per priority |
| GET/PATCH | `/api/tenant/smtp` | SMTP configuration |
| GET/POST/PATCH/DELETE | `/api/tenant/users` | User management |
| GET/PUT | `/api/tenant/agents/[id]/categories` | Agent department + category scoping |

### Super Admin
| Method | Endpoint | Description |
|---|---|---|
| GET | `/api/super-admin/stats` | Platform-wide statistics |
| GET | `/api/super-admin/audit` | Global audit log |
| GET/PATCH | `/api/super-admin/smtp` | Global fallback SMTP |
| GET/POST | `/api/super-admin/tenants` | List / create tenants |
| GET/PATCH/DELETE | `/api/super-admin/tenants/[id]` | Manage individual tenant |
| PATCH | `/api/super-admin/tenants/[id]/features` | Toggle Branding / Integrations feature flags |
| GET/PATCH | `/api/super-admin/tenants/[id]/storage` | Storage quota config |
| GET/PATCH | `/api/super-admin/licenses/[tenantId]` | License plan & limits |

---

## 🔒 SSO & Directory Integration

SSO credentials are configured **per-tenant** in the Tenant Admin panel under **Integrations**. The super admin must first enable the Integrations feature flag for the tenant.

### Supported Providers

#### LDAP / Active Directory
- Bind-DN authentication
- Configurable user filter and group-to-role mapping
- Manual sync trigger or scheduled (cron-based)

#### Azure Active Directory
- OAuth2 / Microsoft Graph API
- Auto-provisioning and deactivation of users
- Group membership → role mapping

#### Google Workspace
- Service account + domain-wide delegation
- Admin SDK Directory API for user sync
- Configurable domain and admin email

### Sync Behavior
- **Auto-provision**: Creates new users found in the directory
- **Auto-deactivate**: Marks users removed from the directory as inactive
- **Role mapping**: Configurable group → EduDesk role mapping (JSON stored per tenant)

---

## 🎨 White-Label Branding

Each tenant can customize their portal appearance (if the super admin has enabled the Branding feature flag):

| Setting | Description |
|---|---|
| Logo & Favicon | Upload custom images |
| Primary / Secondary / Accent Colors | Hex color picker |
| Font Family | Custom font stack |
| Portal Title & Subtitle | Header text on the student portal |
| Welcome Message | Rich introductory message |
| Footer Text | Portal footer |
| Support Email | Displayed contact address |
| Custom CSS | Full CSS injection for advanced styling |

Branding is served via `/api/portal/branding` and applied at portal load time.

---

## 📎 File Attachments

- Files can be attached at **ticket creation** or with any **reply message**
- Submission-time attachments have `messageId = null` and are shown as "initial attachments"
- Per-tenant storage quota configured by super admin (`TenantStorageConfig`)
- Configurable allowed file extensions (e.g. `["pdf","png","jpg","docx","xlsx"]`)
- Files are served via `/api/tickets/[id]/attachments/[uid]/download`
- Default storage location: `./uploads/` (override with `UPLOAD_DIR` env var)

---

## 📋 Ticket Lifecycle

```
[OPEN] ──► [IN_PROGRESS] ──► [RESOLVED] ──► [CLOSED]
               ▲  │
               │  ▼
           [ON_HOLD]
```

- SLA timers start on ticket creation
- Timer pauses while status is `ON_HOLD`
- Breaches are recorded in `sla_logs` with `responseBreached` / `resolveBreached` flags
- SLA targets are configurable per priority: LOW, MEDIUM, HIGH, CRITICAL

---

## 📊 License Plans

| Plan | Target | Max Users | Max Agents |
|---|---|---|---|
| `STARTER` | Small schools | 500 | 1 |
| `PROFESSIONAL` | Mid-size institutions | custom | custom |
| `DISTRICT` | School districts | custom | custom |
| `UNIVERSITY` | Universities | custom | custom |

License status: `TRIAL` · `ACTIVE` · `SUSPENDED` · `EXPIRED`

Feature flags per license (overridden by super admin toggle):
- `featureAd` — SSO / Directory Integration
- `featureCustomBranding` — White-Label Branding
- `featureApi` — API access
- `featureAiBot` — AI assistant
- `featureMultiLang` — Multi-language support

> **Note:** The super admin's **feature flag toggle** (Branding / Integrations) is the **sole authority**. License entitlements do not override it.

---

## 🚀 Production Deployment

### Build
```bash
npm run build
npm start
```

### Recommended Stack
- **Hosting**: Vercel, Railway, or any Node.js 18+ server
- **Database**: Self-hosted MySQL 8+ or AWS RDS (MySQL-compatible)
- **File Storage**: Local disk with NFS mount, or adapt the attachment route for S3/R2
- **Email**: Per-tenant SMTP (Resend, SendGrid, or institutional SMTP relay)
- **Reverse Proxy**: Nginx or Caddy in front of Next.js for SSL termination

### Production Environment Variables
```env
DATABASE_URL="mysql://user:pass@db-host:3306/edudesk?ssl=true"
NEXTAUTH_URL="https://helpdesk.youruniversity.edu"
NEXTAUTH_SECRET="<openssl rand -base64 32>"
UPLOAD_DIR="/var/edudesk/uploads"
```

### Database Migrations
EduDesk uses **Prisma db push** (schemaless migration) for rapid iteration:
```bash
npm run db:push
```

For production, consider exporting `migration.sql` and applying it manually to control the migration timeline.

---

## 🧰 Tech Stack

| Layer | Technology |
|---|---|
| **Framework** | Next.js 16 (App Router) |
| **Language** | TypeScript 5.4 |
| **Database** | MySQL 8 via Prisma ORM 5.11 + mysql2 |
| **Auth** | NextAuth 4.24 (credentials + extensible for OAuth) |
| **LDAP** | ldapts 7 |
| **Email** | Nodemailer 7 |
| **UI Components** | Radix UI (Avatar, Dialog, Dropdown, Select, Tabs, Toast) |
| **Styling** | Tailwind CSS 3.4 |
| **Charts** | Recharts 2.12 |
| **Validation** | Zod 3.22 |
| **Utilities** | clsx, tailwind-merge, date-fns, bcryptjs, lucide-react |

---

## 📄 License

MIT — Free to use for educational institutions.

---

*Built with ❤️ for the education sector · EduDesk v3*
