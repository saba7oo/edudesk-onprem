import { NextRequest, NextResponse } from 'next/server'
import { getToken } from 'next-auth/jwt'

// Paths that never need tenant resolution
const PUBLIC_PATHS = ['/login', '/register', '/api/auth', '/_next', '/favicon']
const SUPER_ADMIN_PATHS = ['/super-admin']

export async function middleware(req: NextRequest) {
  const { pathname, hostname } = req.nextUrl
  const token = await getToken({ req, secret: process.env.NEXTAUTH_SECRET })

  // Skip public paths
  if (PUBLIC_PATHS.some(p => pathname.startsWith(p))) return NextResponse.next()

  // ── Resolve tenant from request ───────────────────────────────────────
  let tenantSlug: string | null = null

  // 1. Subdomain: greenwood.edudesk.com → slug = "greenwood"
  const baseDomain = process.env.NEXT_PUBLIC_BASE_DOMAIN ?? 'edudesk.com'
  if (hostname.endsWith(`.${baseDomain}`)) {
    tenantSlug = hostname.replace(`.${baseDomain}`, '')
  }

  // 2. Custom domain: helpdesk.greenwood.edu → look up in DB via header
  // (set by reverse proxy e.g. nginx/Vercel rewrite)
  const customDomainTenant = req.headers.get('x-tenant-slug')
  if (customDomainTenant) tenantSlug = customDomainTenant

  // 3. Path-based: /t/greenwood/dashboard → slug = "greenwood"
  const pathMatch = pathname.match(/^\/t\/([^\/]+)/)
  if (pathMatch) tenantSlug = pathMatch[1]

  // ── Super admin routes ────────────────────────────────────────────────
  if (pathname.startsWith('/super-admin')) {
    if (!token) return NextResponse.redirect(new URL('/login', req.url))
    if (token.role !== 'SUPER_ADMIN') return NextResponse.redirect(new URL('/', req.url))
    return NextResponse.next()
  }

  // ── API routes - inject tenant context via header ─────────────────────
  if (pathname.startsWith('/api/') && !pathname.startsWith('/api/auth') && !pathname.startsWith('/api/super-admin')) {
    if (!token) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    const response = NextResponse.next()
    if (tenantSlug) response.headers.set('x-tenant-slug', tenantSlug)
    if (token.tenantId) response.headers.set('x-tenant-id', token.tenantId as string)
    return response
  }

  // ── Authenticated app routes ──────────────────────────────────────────
  if (!token) {
    const loginUrl = new URL('/login', req.url)
    if (tenantSlug) loginUrl.searchParams.set('tenant', tenantSlug)
    return NextResponse.redirect(loginUrl)
  }

  // Role-based redirect within tenant
  const role = token.role as string
  if (pathname === '/' || pathname === `/t/${tenantSlug}`) {
    if (role === 'SUPER_ADMIN') return NextResponse.redirect(new URL('/super-admin', req.url))
    if (role === 'TENANT_ADMIN' || role === 'IT_AGENT') {
      return NextResponse.redirect(new URL(tenantSlug ? `/t/${tenantSlug}/dashboard` : '/dashboard', req.url))
    }
    return NextResponse.redirect(new URL(tenantSlug ? `/t/${tenantSlug}/portal` : '/portal', req.url))
  }

  // Inject tenant slug header for downstream use
  const response = NextResponse.next()
  if (tenantSlug) response.headers.set('x-tenant-slug', tenantSlug)
  return response
}

export const config = {
  matcher: ['/((?!_next/static|_next/image|favicon.ico).*)'],
}
