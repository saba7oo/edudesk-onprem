import { PrismaClient } from '@prisma/client'
import bcrypt from 'bcryptjs'

const prisma = new PrismaClient()

async function main() {
  const hash = await bcrypt.hash('Admin@1234', 10)
  await prisma.user.updateMany({
    where: { email: 'admin@greenwood.edu' },
    data: { password: hash }
  })
  console.log('Password reset done')
}

main().finally(() => prisma.$disconnect())