#!/usr/bin/env node
// scripts/migrate.js — Run schema migrations
// Usage: node scripts/migrate.js

require('dotenv').config({ path: '.env.local' });
const mysql = require('mysql2/promise');
const fs    = require('fs');
const path  = require('path');

async function migrate() {
  const connection = await mysql.createConnection({
    host:     process.env.DB_HOST     || 'localhost',
    port:     Number(process.env.DB_PORT) || 3306,
    user:     process.env.DB_USER     || 'root',
    password: process.env.DB_PASSWORD || '',
    multipleStatements: true,
  });

  console.log('🔗 Connected to MySQL');

  const sqlDir  = path.join(__dirname, '..', 'sql');
  const files   = fs.readdirSync(sqlDir).filter(f => f.endsWith('.sql')).sort();

  for (const file of files) {
    const sql = fs.readFileSync(path.join(sqlDir, file), 'utf8');
    console.log(`▶ Running ${file}…`);
    try {
      await connection.query(sql);
      console.log(`  ✓ ${file} complete`);
    } catch (err) {
      console.error(`  ✗ ${file} failed:`, err.message);
    }
  }

  await connection.end();
  console.log('✅ Migration complete');
}

migrate().catch(err => {
  console.error('Migration failed:', err);
  process.exit(1);
});
