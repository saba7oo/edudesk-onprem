-- ============================================================
-- EduDesk Database Schema  |  MySQL 8.0+
-- ============================================================

CREATE DATABASE IF NOT EXISTS edudesk CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE edudesk;

-- ============================================================
-- DEPARTMENTS
-- ============================================================
CREATE TABLE departments (
  id         INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name       VARCHAR(100) NOT NULL,
  slug       VARCHAR(50)  NOT NULL UNIQUE,
  color      VARCHAR(7)   DEFAULT '#2563EB',
  icon       VARCHAR(10)  DEFAULT '🏢',
  is_active  BOOLEAN      DEFAULT TRUE,
  created_at DATETIME     DEFAULT CURRENT_TIMESTAMP
);

INSERT INTO departments (name, slug, color, icon) VALUES
  ('IT Issues',        'it',              '#2563EB', '💻'),
  ('Student Services', 'student-services','#8B5CF6', '🎓'),
  ('Facilities',       'facilities',      '#10B981', '🏫'),
  ('HR & Staff',       'hr',              '#F59E0B', '👔');

-- ============================================================
-- USERS  (synced from AD + local fallback)
-- ============================================================
CREATE TABLE users (
  id            INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  ad_guid       VARCHAR(36)  UNIQUE,
  email         VARCHAR(255) NOT NULL UNIQUE,
  full_name     VARCHAR(150) NOT NULL,
  role          ENUM('student','teacher','staff','agent','admin') NOT NULL DEFAULT 'student',
  department_id INT UNSIGNED,
  student_id    VARCHAR(30),
  phone         VARCHAR(30),
  avatar_url    VARCHAR(500),
  is_active     BOOLEAN      DEFAULT TRUE,
  password_hash VARCHAR(255),
  last_login    DATETIME,
  ad_synced_at  DATETIME,
  created_at    DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at    DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (department_id) REFERENCES departments(id) ON DELETE SET NULL,
  INDEX idx_email   (email),
  INDEX idx_role    (role),
  INDEX idx_ad_guid (ad_guid)
);

-- ============================================================
-- AD SYNC LOG
-- ============================================================
CREATE TABLE ad_sync_logs (
  id                INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  synced_at         DATETIME DEFAULT CURRENT_TIMESTAMP,
  users_added       INT DEFAULT 0,
  users_updated     INT DEFAULT 0,
  users_deactivated INT DEFAULT 0,
  status            ENUM('success','partial','failed') DEFAULT 'success',
  error_msg         TEXT
);

-- ============================================================
-- TICKETS
-- ============================================================
CREATE TABLE tickets (
  id            INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  ticket_number VARCHAR(12)  NOT NULL UNIQUE,
  title         VARCHAR(255) NOT NULL,
  description   TEXT         NOT NULL,
  department_id INT UNSIGNED NOT NULL,
  submitter_id  INT UNSIGNED NOT NULL,
  assigned_to   INT UNSIGNED,
  priority      ENUM('low','medium','high','critical') NOT NULL DEFAULT 'medium',
  status        ENUM('open','in_progress','pending_user','resolved','closed') NOT NULL DEFAULT 'open',
  source        ENUM('portal','email','phone','walk_in') DEFAULT 'portal',
  due_at        DATETIME,
  resolved_at   DATETIME,
  closed_at     DATETIME,
  satisfaction  TINYINT UNSIGNED,
  created_at    DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at    DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (department_id) REFERENCES departments(id),
  FOREIGN KEY (submitter_id)  REFERENCES users(id),
  FOREIGN KEY (assigned_to)   REFERENCES users(id) ON DELETE SET NULL,
  INDEX idx_status        (status),
  INDEX idx_priority      (priority),
  INDEX idx_submitter     (submitter_id),
  INDEX idx_assigned      (assigned_to),
  INDEX idx_dept          (department_id),
  INDEX idx_created       (created_at),
  INDEX idx_ticket_number (ticket_number)
);

-- ============================================================
-- TICKET MESSAGES
-- ============================================================
CREATE TABLE ticket_messages (
  id          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  ticket_id   INT UNSIGNED NOT NULL,
  sender_id   INT UNSIGNED NOT NULL,
  body        TEXT         NOT NULL,
  is_internal BOOLEAN      DEFAULT FALSE,
  created_at  DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (ticket_id) REFERENCES tickets(id) ON DELETE CASCADE,
  FOREIGN KEY (sender_id) REFERENCES users(id),
  INDEX idx_ticket  (ticket_id),
  INDEX idx_created (created_at)
);

-- ============================================================
-- TICKET ATTACHMENTS
-- ============================================================
CREATE TABLE ticket_attachments (
  id           INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  ticket_id    INT UNSIGNED NOT NULL,
  message_id   INT UNSIGNED,
  uploader_id  INT UNSIGNED NOT NULL,
  filename     VARCHAR(255) NOT NULL,
  storage_path VARCHAR(500) NOT NULL,
  mime_type    VARCHAR(100),
  size_bytes   INT UNSIGNED,
  created_at   DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (ticket_id)   REFERENCES tickets(id) ON DELETE CASCADE,
  FOREIGN KEY (message_id)  REFERENCES ticket_messages(id) ON DELETE SET NULL,
  FOREIGN KEY (uploader_id) REFERENCES users(id)
);

-- ============================================================
-- TICKET HISTORY / AUDIT LOG
-- ============================================================
CREATE TABLE ticket_history (
  id         INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  ticket_id  INT UNSIGNED NOT NULL,
  actor_id   INT UNSIGNED,
  action     VARCHAR(50)  NOT NULL,
  old_value  VARCHAR(255),
  new_value  VARCHAR(255),
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (ticket_id) REFERENCES tickets(id) ON DELETE CASCADE,
  FOREIGN KEY (actor_id)  REFERENCES users(id) ON DELETE SET NULL,
  INDEX idx_ticket  (ticket_id),
  INDEX idx_created (created_at)
);

-- ============================================================
-- SLA POLICIES
-- ============================================================
CREATE TABLE sla_policies (
  id              INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name            VARCHAR(100) NOT NULL,
  department_id   INT UNSIGNED,
  priority        ENUM('low','medium','high','critical') NOT NULL,
  response_hours  DECIMAL(5,1) NOT NULL,
  resolve_hours   DECIMAL(5,1) NOT NULL,
  is_active       BOOLEAN DEFAULT TRUE,
  created_at      DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (department_id) REFERENCES departments(id) ON DELETE CASCADE
);

INSERT INTO sla_policies (name, priority, response_hours, resolve_hours) VALUES
  ('Critical - Default', 'critical', 1,   4),
  ('High - Default',     'high',     4,   24),
  ('Medium - Default',   'medium',   8,   72),
  ('Low - Default',      'low',      24,  168);

-- ============================================================
-- KNOWLEDGE BASE
-- ============================================================
CREATE TABLE kb_categories (
  id            INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name          VARCHAR(100) NOT NULL,
  department_id INT UNSIGNED,
  icon          VARCHAR(10),
  FOREIGN KEY (department_id) REFERENCES departments(id) ON DELETE SET NULL
);

CREATE TABLE kb_articles (
  id           INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  category_id  INT UNSIGNED,
  title        VARCHAR(255) NOT NULL,
  slug         VARCHAR(255) NOT NULL UNIQUE,
  body         LONGTEXT     NOT NULL,
  author_id    INT UNSIGNED,
  view_count   INT UNSIGNED DEFAULT 0,
  is_published BOOLEAN DEFAULT TRUE,
  created_at   DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at   DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (category_id) REFERENCES kb_categories(id) ON DELETE SET NULL,
  FOREIGN KEY (author_id)   REFERENCES users(id) ON DELETE SET NULL,
  FULLTEXT INDEX ft_search (title, body)
);

-- ============================================================
-- ANNOUNCEMENTS
-- ============================================================
CREATE TABLE announcements (
  id         INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  title      VARCHAR(255) NOT NULL,
  body       TEXT,
  type       ENUM('info','warning','outage','maintenance') DEFAULT 'info',
  author_id  INT UNSIGNED,
  starts_at  DATETIME,
  ends_at    DATETIME,
  is_active  BOOLEAN DEFAULT TRUE,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (author_id) REFERENCES users(id) ON DELETE SET NULL
);

-- ============================================================
-- NOTIFICATIONS
-- ============================================================
CREATE TABLE notifications (
  id         INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id    INT UNSIGNED NOT NULL,
  ticket_id  INT UNSIGNED,
  type       VARCHAR(50)  NOT NULL,
  title      VARCHAR(255) NOT NULL,
  body       TEXT,
  is_read    BOOLEAN DEFAULT FALSE,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id)   REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (ticket_id) REFERENCES tickets(id) ON DELETE SET NULL,
  INDEX idx_user_unread (user_id, is_read)
);

-- ============================================================
-- REVOKED JWT TOKENS (logout blacklist)
-- ============================================================
CREATE TABLE revoked_tokens (
  id         INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  jti        VARCHAR(36) NOT NULL UNIQUE,
  revoked_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  expires_at DATETIME NOT NULL,
  INDEX idx_jti     (jti),
  INDEX idx_expires (expires_at)
);
