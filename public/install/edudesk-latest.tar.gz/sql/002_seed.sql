-- ============================================================
-- EduDesk Seed Data  |  Development / Demo
-- ============================================================
USE edudesk;

-- Admin user (password: Admin@123)
INSERT INTO users (email, full_name, role, is_active, password_hash) VALUES
  ('admin@greenwood.edu', 'System Admin', 'admin', TRUE,
   '$2a$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi');

-- IT Agents
INSERT INTO users (email, full_name, role, department_id, is_active, password_hash) VALUES
  ('mohammed.k@greenwood.edu', 'Mohammed Khalil',   'agent', 1, TRUE, '$2a$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi'),
  ('layla.h@greenwood.edu',    'Layla Hassan',      'agent', 1, TRUE, '$2a$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi'),
  ('facilities@greenwood.edu', 'Facilities Team',   'agent', 3, TRUE, '$2a$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi');

-- Students
INSERT INTO users (email, full_name, role, student_id, is_active, password_hash) VALUES
  ('sara.alrashid@student.greenwood.edu',  'Sara Al-Rashid', 'student', 'S20210045', TRUE, '$2a$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi'),
  ('ahmed.yilmaz@student.greenwood.edu',   'Ahmed Yilmaz',   'student', 'S20210087', TRUE, '$2a$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi'),
  ('nour.khalid@student.greenwood.edu',    'Nour Khalid',    'student', 'S20220012', TRUE, '$2a$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi');

-- Teachers
INSERT INTO users (email, full_name, role, department_id, is_active, password_hash) VALUES
  ('james.osei@greenwood.edu',  'Prof. James Osei', 'teacher', 1, TRUE, '$2a$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi'),
  ('chen.wei@greenwood.edu',    'Dr. Chen Wei',     'teacher', 1, TRUE, '$2a$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi');

-- Staff
INSERT INTO users (email, full_name, role, department_id, is_active, password_hash) VALUES
  ('fatima.z@greenwood.edu', 'Fatima Al-Zahra', 'staff', 4, TRUE, '$2a$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi');

-- Sample tickets
INSERT INTO tickets (ticket_number, title, description, department_id, submitter_id, assigned_to, priority, status, created_at) VALUES
  ('TK-1041', 'Cannot connect to campus WiFi',
   'I am unable to connect to CampusNet from my laptop in Building C. I have tried restarting and forgetting the network.',
   1, 5, 2, 'high', 'in_progress', NOW() - INTERVAL 2 HOUR),

  ('TK-1040', 'Projector not working in Room 204',
   'The projector in Room 204 shows No Signal when connected via HDMI. Class starts at 11am.',
   3, 8, 3, 'medium', 'in_progress', NOW() - INTERVAL 3 HOUR),

  ('TK-1039', 'Student ID card replacement request',
   'I lost my student ID card and need a replacement urgently for library and lab access.',
   2, 5, NULL, 'low', 'open', NOW() - INTERVAL 4 HOUR),

  ('TK-1038', 'Outlook license not activating',
   'Microsoft Outlook keeps asking me to sign in and says my license is not valid. I use it for work email.',
   1, 10, 2, 'high', 'in_progress', NOW() - INTERVAL 6 HOUR),

  ('TK-1037', 'New staff onboarding - AD account needed',
   'New staff member starting Monday. Need AD account, email, and VPN access set up before then.',
   4, 1, NULL, 'critical', 'open', NOW() - INTERVAL 8 HOUR),

  ('TK-1036', 'Lab computers running slow after update',
   'All 12 computers in Lab B are very slow since the Windows update last night. Students cannot work.',
   1, 8, 2, 'medium', 'resolved', NOW() - INTERVAL 1 DAY),

  ('TK-1035', 'Broken chair in Library reading room',
   'There is a broken chair on the 2nd floor of the library near the study pods. It is a safety hazard.',
   3, 6, 3, 'low', 'resolved', NOW() - INTERVAL 2 DAY);

-- Sample messages
INSERT INTO ticket_messages (ticket_id, sender_id, body, is_internal, created_at) VALUES
  (1, 5, 'I have tried restarting my laptop and forgetting the network, still cannot connect.', FALSE, NOW() - INTERVAL 100 MINUTE),
  (1, 2, 'Hi Sara, could you tell me the exact building and floor you are on? Also, what device are you using?', FALSE, NOW() - INTERVAL 80 MINUTE),
  (1, 5, 'I am in Building C, 3rd floor. Using a MacBook Pro M2.', FALSE, NOW() - INTERVAL 60 MINUTE),
  (1, 2, 'Checking the MAC address filter - give me a moment.', TRUE, NOW() - INTERVAL 50 MINUTE),

  (2, 8, 'I have a class at 11am and really need this fixed. The cable looks fine.', FALSE, NOW() - INTERVAL 150 MINUTE),
  (2, 3, 'Sending a tech to Room 204 before your class. Can you check if the HDMI port on the laptop is clean?', FALSE, NOW() - INTERVAL 120 MINUTE);

-- KB categories
INSERT INTO kb_categories (name, department_id, icon) VALUES
  ('Network & WiFi',      1, '📶'),
  ('Accounts & Access',   1, '🔑'),
  ('Hardware',            1, '🖥'),
  ('Student Services',    2, '🎓'),
  ('Facilities',          3, '🏫');

-- KB articles
INSERT INTO kb_articles (category_id, title, slug, body, author_id, view_count) VALUES
  (1, 'How to connect to CampusNet WiFi',
   'connect-campusnet-wifi',
   '## Connecting to CampusNet\n\n1. Open your WiFi settings\n2. Select **CampusNet** from the list\n3. Enter your university email and password\n4. Accept the security certificate\n\nIf you still cannot connect, submit a ticket.',
   1, 2400),

  (2, 'Resetting your portal password',
   'reset-portal-password',
   '## Password Reset\n\nVisit the self-service portal at **accounts.greenwood.edu** and click "Forgot Password". You will receive an email with a reset link valid for 30 minutes.',
   1, 870),

  (4, 'Lost or damaged student ID card',
   'lost-student-id',
   '## Replacing Your Student ID\n\nVisit the Student Services office on the ground floor of the Admin Building with:\n- Your student number\n- A government-issued photo ID\n\nReplacement fee: 25 SAR. Same-day processing available.',
   1, 1200);
