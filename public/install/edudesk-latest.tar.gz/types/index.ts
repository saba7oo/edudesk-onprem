// ============================================================
// EduDesk — Shared TypeScript Types
// ============================================================

export type UserRole = 'student' | 'teacher' | 'staff' | 'agent' | 'admin';
export type TicketStatus = 'open' | 'in_progress' | 'pending_user' | 'resolved' | 'closed';
export type TicketPriority = 'low' | 'medium' | 'high' | 'critical';
export type TicketSource = 'portal' | 'email' | 'phone' | 'walk_in';

export interface User {
  id:            number;
  ad_guid?:      string;
  email:         string;
  full_name:     string;
  role:          UserRole;
  department_id?: number;
  department?:   Department;
  student_id?:   string;
  phone?:        string;
  avatar_url?:   string;
  is_active:     boolean;
  last_login?:   string;
  created_at:    string;
}

export interface Department {
  id:        number;
  name:      string;
  slug:      string;
  color:     string;
  icon:      string;
  is_active: boolean;
}

export interface Ticket {
  id:            number;
  ticket_number: string;
  title:         string;
  description:   string;
  department_id: number;
  department?:   Department;
  submitter_id:  number;
  submitter?:    User;
  assigned_to?:  number;
  agent?:        User;
  priority:      TicketPriority;
  status:        TicketStatus;
  source:        TicketSource;
  due_at?:       string;
  resolved_at?:  string;
  closed_at?:    string;
  satisfaction?: number;
  created_at:    string;
  updated_at:    string;
  messages?:     TicketMessage[];
  history?:      TicketHistoryEntry[];
}

export interface TicketMessage {
  id:          number;
  ticket_id:   number;
  sender_id:   number;
  sender?:     User;
  body:        string;
  is_internal: boolean;
  created_at:  string;
}

export interface TicketHistoryEntry {
  id:         number;
  ticket_id:  number;
  actor_id?:  number;
  actor?:     User;
  action:     string;
  old_value?: string;
  new_value?: string;
  created_at: string;
}

export interface SLAPolicy {
  id:             number;
  name:           string;
  department_id?: number;
  priority:       TicketPriority;
  response_hours: number;
  resolve_hours:  number;
  is_active:      boolean;
}

export interface KBArticle {
  id:           number;
  category_id?: number;
  title:        string;
  slug:         string;
  body:         string;
  author_id?:   number;
  view_count:   number;
  is_published: boolean;
  created_at:   string;
  updated_at:   string;
}

export interface Notification {
  id:         number;
  user_id:    number;
  ticket_id?: number;
  ticket?:    Ticket;
  type:       string;
  title:      string;
  body?:      string;
  is_read:    boolean;
  created_at: string;
}

export interface DashboardStats {
  open:           number;
  in_progress:    number;
  resolved_today: number;
  avg_resolve_h:  number;
  by_dept:        { dept: string; count: number; color: string }[];
  by_priority:    { priority: string; count: number }[];
  tickets_7d:     { date: string; count: number }[];
  top_agents:     { name: string; open: number; resolved: number; avg_hours: number }[];
}

// API response shapes
export interface ApiResponse<T = any> {
  data?:    T;
  error?:   string;
  message?: string;
}

export interface PaginatedResponse<T> {
  data:    T[];
  total:   number;
  page:    number;
  limit:   number;
  pages:   number;
}
